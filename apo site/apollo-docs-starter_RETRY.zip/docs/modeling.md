# Modeling (CATIA)

CATIA 기반 파트/어셈/도면, FEA 연계 규칙.
